import '/src/App.css'

function App() {
  return (
      <>
          <h1>A bunch of static HTML + . /App.css</h1>
          <a href={"/Easy.html"}>/src/Easy.html</a> <br/>
          <a href={"/Medium.html"}>/src/Medium.html</a> <br/>
          <a  href={"/Hard.html"}>/src/Hard.html</a> <br/>
      </>
  )
}

export default App
