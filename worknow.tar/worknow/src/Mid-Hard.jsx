import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import Hard from '/src/Hard.jsx'

createRoot(document.getElementById('root')).render(
    <StrictMode>
        <Hard />
    </StrictMode>,
)
