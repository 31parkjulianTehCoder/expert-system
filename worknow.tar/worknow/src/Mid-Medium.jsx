import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import Medium from './Medium.jsx'

createRoot(document.getElementById('root')).render(
    <StrictMode>
        <Medium />
    </StrictMode>,
)
